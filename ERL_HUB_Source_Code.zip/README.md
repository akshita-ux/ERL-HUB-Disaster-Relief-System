# ERL-HUB – Post-Earthquake Multi-Agency Emergency Relief Logistics Hub

**Course:** CIC-211 – OOPs Using C++  
**Language:** Standard C++17  
**Submission:** Individual

## 1. Aim
To design and implement a modular, menu-driven C++ system that coordinates relief inventory, heterogeneous transport vehicles, emergency mission prioritisation, dispatch operations and persistent incident auditing after an earthquake.

## 2. Objectives
- Maintain relief inventory at a regional distribution depot.
- Represent ground, aerial and amphibious transport vehicles.
- Allocate and dispatch supplies according to mission priority.
- Prevent dispatch when payload, fuel or route constraints are violated.
- Preserve incident records in a binary file.
- Demonstrate all four units of the CIC-211 syllabus.

## 3. Files
- `main.cpp` – application entry point.
- `erl_hub.hpp` – class declarations, templates, namespaces and interfaces.
- `erl_hub.cpp` – class implementations and application menu.
- `erl_incidents.bin` – generated binary incident log (created at runtime).

## 4. Build
Using g++:
```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp erl_hub.cpp -o erl_hub
./erl_hub
```
On Windows with MinGW:
```bash
g++ -std=c++17 -Wall -Wextra -pedantic main.cpp erl_hub.cpp -o erl_hub.exe
erl_hub.exe
```

## 5. Menu
1. View inventory
2. Restock supplies
3. Register/dispatch ground convoy
4. Register/dispatch helicopter
5. Register/dispatch amphibious craft
6. Add mission to priority queue
7. View missions by priority
8. Dispatch next mission
9. View binary incident history
10. View system analytics
0. Exit

The initial depot contains Rations, Medicine, Water and Blankets. For ease of console entry, mission destinations and supply names are entered as one word. The class interfaces support normal strings.

## 6. CIC-211 requirement mapping

### Unit I – Core foundations and call semantics
- `ReliefOps::Logistics` and `ReliefOps::Inventory` namespaces.
- Inline `calculateDistance()` and `calculatePayloadVolume()`.
- Overloaded `allocateSupply()` for standard and emergency-priority allocation.
- Reference parameter/return: `adjustMissionPriority(double&, double)` and depot `stock()` returns a reference.
- Friend class `IncidentCommander` changes a cargo's private priority during emergency triage.

### Unit II – Encapsulation, dynamic memory and operators
- Encapsulated `ReliefCargo`, `DistributionDepot`, `Manifest`, and `TransportVehicle`.
- Static depot count, active vehicle count and dispatched tonnage.
- `Manifest` owns a dynamic `ReliefCargo[]`; parameterised constructor, deep copy constructor, copy assignment, move operations and destructor.
- `DistributionDepot::operator+=` restocks.
- `TransportVehicle::operator-=` validates cargo loading/deduction eligibility.
- `Manifest::operator==` compares manifest identity.
- `ReliefCargo` overloads `<<` and `>>`; `Manifest` overloads `<<`.

### Unit III – inheritance, containership and polymorphism
- `ReliefVehicle` is an abstract base class with pure virtual `type()` and `evaluateRoute()`.
- `GroundConvoy` and `AerialTransport` virtually inherit `ReliefVehicle`; `AmphibiousCraft` derives from both, resolving the diamond.
- `GPSBeacon` and `EmergencyLifeSupportUnit` are composed as independent member objects in `ReliefVehicle`.
- Virtual destructor ensures correct derived destruction through base ownership (`unique_ptr<ReliefVehicle>`).
- Calls to `evaluateRoute()` and `dispatch()` use runtime polymorphism.

### Unit IV – streams, persistence, exceptions and STL
- Custom exceptions: `CargoOverweightException`, `FuelDepletionException`, `DamagedCorridorException`.
- `BinaryIncidentLogger` uses binary `std::fstream`, `seekp()` and `seekg()` to append, verify and roll back failed writes.
- STL: `vector`, `map`, `unordered_map`, `sort`, `min_element`.
- `PriorityDispatchQueue<T>` is a generic template.
- `UrgencyFirst` is a custom sorting functor.
- `tableHeader()` is a user-defined stream manipulator for tabular mission output.

## 7. Sample test scenario
1. Choose `1` to view initial stock.
2. Choose `3` to dispatch a ground convoy:
   - Vehicle ID: TRK-01
   - Destination: Chamoli
   - Supply: Rations
   - Quantity: 20
   - Priority: 1
   - Distance: 40
3. Choose `9` to inspect the binary incident history.
4. Choose `10` to inspect system analytics.

The seeded inventory uses one-word names so the simple console input parser can accept them directly. The underlying cargo classes support names containing spaces.
